import pyodbc

# ===========================
# НАСТРОЙКА ПОДКЛЮЧЕНИЯ
# ===========================
# 1) Узнай в SSMS имя сервера (Object Explorer -> верх)
# Пример: localhost\\SQLEXPRESS  или  DESKTOP-123\\SQLEXPRESS
SERVER_NAME = r"localhost\SQLEXPRESS01"
DB_NAME = "khasanov"

CONNECTION_STRING = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    f"SERVER={SERVER_NAME};"
    f"DATABASE={DB_NAME};"
    "Trusted_Connection=yes;"
)

def get_conn():
    return pyodbc.connect(CONNECTION_STRING)

# ===========================
# АВТОРИЗАЦИЯ
# ===========================
def get_user_by_login_password(login: str, password: str):
    sql = """
    SELECT u.id_user, u.fio, u.login, u.password, u.id_role, r.name AS role_name
    FROM users u
    JOIN roles r ON r.id_role = u.id_role
    WHERE u.login = ? AND u.password = ?;
    """
    with get_conn() as conn:
        cur = conn.cursor()
        row = cur.execute(sql, login, password).fetchone()
        if not row:
            return None
        return {
            "id_user": row.id_user,
            "fio": row.fio,
            "login": row.login,
            "id_role": row.id_role,
            "role_name": row.role_name
        }

# ===========================
# ТОВАРЫ (просмотр)
# ===========================
def get_products_filtered(search_text: str = "", sort_mode: str = "AZ", provider_id=None):
    """
    sort_mode: "AZ" = по названию А-Я, "ZA" = Я-А
    provider_id: None = все поставщики, иначе фильтр по id_provider
    """
    order = "ASC" if sort_mode == "AZ" else "DESC"

    sql = f"""
    SELECT p.id_tovar, p.article, p.name, p.unit, p.price, p.discount, p.qty,
           c.name AS category, pr.name AS provider, m.name AS manufacturer
    FROM products p
    JOIN categories c ON c.id_category = p.id_category
    JOIN providers pr ON pr.id_provider = p.id_provider
    JOIN manufacturers m ON m.id_manufacturer = p.id_manufacturer
    WHERE (p.name LIKE ? OR p.article LIKE ?)
    """

    params = [f"%{search_text}%", f"%{search_text}%"]

    if provider_id is not None:
        sql += " AND p.id_provider = ?"
        params.append(provider_id)

    sql += f" ORDER BY p.name {order};"

    with get_conn() as conn:
        cur = conn.cursor()
        return cur.execute(sql, params).fetchall()


# Справочник адресов (пункты выдачи)
def get_addresses():
    sql = "SELECT id_address, name FROM addresses ORDER BY id_address;"
    with get_conn() as conn:
        rows = conn.cursor().execute(sql).fetchall()
        return [(r.id_address, r.name) for r in rows]
# Создание заказа + позиции
def create_order(id_user, id_address, code, id_state=1, date_start=None, date_end=None):
    """
    id_user может быть None (гость).
    code — уникальный код заказа (число).
    """
    sql = """
    INSERT INTO orders(date_start, date_end, id_address, id_user, code, id_state)
    OUTPUT INSERTED.id_order
    VALUES (COALESCE(?, CAST(GETDATE() AS DATE)), ?, ?, ?, ?, ?);
    """
    with get_conn() as conn:
        cur = conn.cursor()
        row = cur.execute(sql, date_start, date_end, id_address, id_user, code, id_state).fetchone()
        conn.commit()
        return int(row[0])

def add_order_item(id_order, id_tovar, qty):
    sql = """
    INSERT INTO order_items(id_order, id_tovar, qty)
    VALUES (?, ?, ?);
    """
    with get_conn() as conn:
        conn.cursor().execute(sql, id_order, id_tovar, qty)
        conn.commit()
# Получить заказы пользователя (оформленные заказы)
def get_orders_for_user(id_user: int):
    sql = """
    SELECT o.id_order, o.code, o.date_start, o.date_end, s.name AS status, a.name AS address
    FROM orders o
    JOIN states s ON s.id_state = o.id_state
    JOIN addresses a ON a.id_address = o.id_address
    WHERE o.id_user = ?
    ORDER BY o.id_order DESC;
    """
    with get_conn() as conn:
        return conn.cursor().execute(sql, id_user).fetchall()

def get_order_items(id_order: int):
    sql = """
    SELECT p.article, p.name, oi.qty, p.price
    FROM order_items oi
    JOIN products p ON p.id_tovar = oi.id_tovar
    WHERE oi.id_order = ?
    ORDER BY p.name;
    """
    with get_conn() as conn:
        return conn.cursor().execute(sql, id_order).fetchall()

# ===========================
# СПРАВОЧНИКИ ДЛЯ CRUD (админ)
# ===========================
def get_lookup(table_name: str):
    allowed = {"categories", "providers", "manufacturers"}
    if table_name not in allowed:
        raise ValueError("Unsupported lookup table")

    id_col = {
        "categories": "id_category",
        "providers": "id_provider",
        "manufacturers": "id_manufacturer"
    }[table_name]

    sql = f"SELECT {id_col} AS id, name FROM {table_name} ORDER BY id;"
    with get_conn() as conn:
        rows = conn.cursor().execute(sql).fetchall()
        return [(r.id, r.name) for r in rows]

# ===========================
# ТОВАРЫ (CRUD для админа)
# ===========================
def add_product(article, name, unit, price, max_discount,
                id_manufacturer, id_provider, id_category,
                discount, qty, description, photo):
    sql = """
    INSERT INTO products
      (article, name, unit, price, max_discount, id_manufacturer, id_provider, id_category,
       discount, qty, description, photo)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    with get_conn() as conn:
        conn.cursor().execute(sql,
            article, name, unit, price, max_discount,
            id_manufacturer, id_provider, id_category,
            discount, qty, description, photo
        )
        conn.commit()

def update_product(id_tovar, article, name, unit, price, max_discount,
                   id_manufacturer, id_provider, id_category,
                   discount, qty, description, photo):
    sql = """
    UPDATE products
    SET article=?, name=?, unit=?, price=?, max_discount=?,
        id_manufacturer=?, id_provider=?, id_category=?,
        discount=?, qty=?, description=?, photo=?
    WHERE id_tovar=?;
    """
    with get_conn() as conn:
        conn.cursor().execute(sql,
            article, name, unit, price, max_discount,
            id_manufacturer, id_provider, id_category,
            discount, qty, description, photo,
            id_tovar
        )
        conn.commit()

def delete_product(id_tovar):
    sql = "DELETE FROM products WHERE id_tovar=?;"
    with get_conn() as conn:
        conn.cursor().execute(sql, id_tovar)
        conn.commit()

def get_states():
    sql = "SELECT id_state, name FROM states ORDER BY id_state;"
    with get_conn() as conn:
        rows = conn.cursor().execute(sql).fetchall()
        return [(r.id_state, r.name) for r in rows]

def update_order(id_order: int, id_state: int, id_address: int, date_end):
    sql = """
    UPDATE orders
    SET id_state = ?, id_address = ?, date_end = ?
    WHERE id_order = ?;
    """
    with get_conn() as conn:
        conn.cursor().execute(sql, id_state, id_address, date_end, id_order)
        conn.commit()
