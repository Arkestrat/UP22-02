import tkinter as tk
from tkinter import ttk, messagebox
import db

ROLE_ADMIN = "Администратор"

# ===========================
# ОКНО АВТОРИЗАЦИИ
# ===========================
class LoginWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ООО «Творчество» — Авторизация")
        self.geometry("420x230")
        self.resizable(False, False)

        tk.Label(self, text="Логин (email):").pack(pady=(15, 0))
        self.login_entry = tk.Entry(self, width=40)
        self.login_entry.pack()

        tk.Label(self, text="Пароль:").pack(pady=(10, 0))
        self.password_entry = tk.Entry(self, width=40, show="*")
        self.password_entry.pack()

        btn_frame = tk.Frame(self)
        btn_frame.pack(pady=15)


        tk.Button(btn_frame, text="Войти", width=15, command=self.on_login).grid(row=0, column=0, padx=8)
        tk.Button(btn_frame, text="Войти как гость", width=15, command=self.on_guest).grid(row=0, column=1, padx=8)

        tk.Label(self, text="Настрой подключение в db.py (SERVER_NAME, DB_NAME)", fg="gray").pack()

    def edit_order(self):
        oid = self.selected_order_id()
        if oid is None:
            messagebox.showwarning("Внимание", "Выберите заказ.")
            return

        OrderEditor(self, order_id=oid, on_saved=self.load)

    def on_guest(self):
        self.destroy()
        ProductsWindow(user=None).mainloop()

    def on_login(self):
        login = self.login_entry.get().strip()
        password = self.password_entry.get().strip()

        if not login or not password:
            messagebox.showwarning("Ошибка", "Введите логин и пароль.")
            return

        try:
            user = db.get_user_by_login_password(login, password)
        except Exception as e:
            messagebox.showerror("Ошибка БД", f"Не удалось подключиться к базе данных.\n\n{e}")
            return

        if not user:
            messagebox.showerror("Ошибка", "Неверный логин или пароль.")
            return

        self.destroy()
        ProductsWindow(user=user).mainloop()


# ===========================
# ОКНО ТОВАРОВ
# ===========================
class ProductsWindow(tk.Tk):
    def open_cart(self):
        CartWindow(self)

    def open_orders(self):
        OrdersWindow(self, self.user["id_user"])

    def apply_filters(self):
        q = self.search_var.get().strip()
        sort_mode = "AZ" if self.sort_var.get() == "А → Я" else "ZA"

        selected = self.cb_provider.get()
        provider_id = None
        if selected != "Все":
            provider_id = int(selected.split("—")[0].strip())

        self.load_products(search_text=q, sort_mode=sort_mode, provider_id=provider_id)

    def reset_filters(self):
        self.search_var.set("")
        self.sort_var.set("А → Я")
        self.cb_provider.current(0)
        self.load_products()

    def reset_filters(self):
        self.search_var.set("")
        self.sort_var.set("А → Я")
        self.cb_provider.current(0)
        self.load_products()

    def add_to_cart(self):
        pid = self.get_selected_id()
        if pid is None:
            messagebox.showwarning("Внимание", "Выберите товар.")
            return

        # количество по умолчанию +1
        self.cart[pid] = self.cart.get(pid, 0) + 1
        messagebox.showinfo("Корзина", "Товар добавлен в корзину.")

    def __init__(self, user):
        super().__init__()
        self.user = user
        self.title("ООО «Творчество» — Товары")
        self.geometry("1120x520")

        role = "Гость" if user is None else user["role_name"]
        fio = "" if user is None else user["fio"]
        header = f"Пользователь: {fio}   Роль: {role}" if user else "Пользователь: Гость"
        tk.Label(self, text=header, font=("Segoe UI", 11)).pack(anchor="w", padx=10, pady=8)
        # --- Панель поиск/сортировка/поставщик ---
        top = tk.Frame(self)
        top.pack(fill="x", padx=10)

        tk.Label(top, text="Поиск:").pack(side="left")
        self.search_var = tk.StringVar()
        tk.Entry(top, textvariable=self.search_var, width=25).pack(side="left", padx=6)

        tk.Label(top, text="Сортировка:").pack(side="left", padx=(10, 0))
        self.sort_var = tk.StringVar(value="А → Я")
        ttk.Combobox(
            top, textvariable=self.sort_var,
            values=["А → Я", "Я → А"],
            state="readonly", width=8
        ).pack(side="left", padx=6)


        tk.Label(top, text="Поставщик:").pack(side="left", padx=(10, 0))
        self.providers = [(None, "Все")] + db.get_lookup("providers")
        self.provider_var = tk.StringVar()
        self.cb_provider = ttk.Combobox(
            top,
            textvariable=self.provider_var,
            state="readonly",
            values=["Все"] + [f"{i} — {n}" for i, n in self.providers if i is not None],
            width=22
        )
        self.cb_provider.pack(side="left", padx=6)
        self.cb_provider.current(0)

        tk.Button(top, text="Применить", command=self.apply_filters).pack(side="left", padx=6)
        tk.Button(top, text="Сброс", command=self.reset_filters).pack(side="left")

        columns = ("id", "article", "name", "unit", "price", "discount", "qty", "category", "provider", "manufacturer")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=18)
        self.tree.pack(fill="both", expand=True, padx=10, pady=5)

        headings = {
            "id": "ID",
            "article": "Артикул",
            "name": "Название",
            "unit": "Ед.",
            "price": "Цена",
            "discount": "Скидка",
            "qty": "Кол-во",
            "category": "Категория",
            "provider": "Поставщик",
            "manufacturer": "Производитель"
        }
        # --- Панель поиск/сортировка ---
        top = tk.Frame(self)
        top.pack(fill="x", padx=10)

        tk.Label(top, text="Поиск:").pack(side="left")
        self.search_var = tk.StringVar()
        tk.Entry(top, textvariable=self.search_var, width=35).pack(side="left", padx=6)

        tk.Label(top, text="Сортировка:").pack(side="left", padx=(10, 0))
        self.sort_var = tk.StringVar(value="А → Я")
        sort_cb = ttk.Combobox(top, textvariable=self.sort_var, state="readonly",
                               values=["А → Я", "Я → А"], width=8)
        sort_cb.pack(side="left", padx=6)

        tk.Button(top, text="Найти", command=self.apply_filters).pack(side="left", padx=6)
        tk.Button(top, text="Сброс", command=self.reset_filters).pack(side="left")

        for c in columns:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=90 if c in ("id", "unit", "discount", "qty") else 150)

        btn_frame = tk.Frame(self)
        btn_frame.pack(fill="x", padx=10, pady=8)


        tk.Button(btn_frame, text="Обновить", command=self.load_products).pack(side="left")
       
        tk.Button(btn_frame, text="Добавить в корзину", command=self.add_to_cart).pack(side="left", padx=6)
        tk.Button(btn_frame, text="Корзина / Оформить", command=self.open_cart).pack(side="left", padx=6)

        # Для авторизованных — "Мои заказы"
        if self.user is not None:
            tk.Button(btn_frame, text="Мои заказы", command=self.open_orders).pack(side="left", padx=6)

        # корзина в памяти
        self.cart = {}  # {id_tovar: qty}

        self.is_admin = (user is not None and user["role_name"] == ROLE_ADMIN)
        if self.is_admin:
            tk.Button(btn_frame, text="Добавить товар", command=self.open_add).pack(side="left", padx=6)
            tk.Button(btn_frame, text="Редактировать", command=self.open_edit).pack(side="left", padx=6)
            tk.Button(btn_frame, text="Удалить", command=self.delete_selected).pack(side="left", padx=6)

        tk.Button(btn_frame, text="Выход", command=self.destroy).pack(side="right")

        self.load_products()

    def load_products(self, search_text="", sort_mode="AZ", provider_id=None):
        for i in self.tree.get_children():
            self.tree.delete(i)

        try:
            rows = db.get_products_filtered(
                search_text=search_text,
                sort_mode=sort_mode,
                provider_id=provider_id
            )
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить товары.\n\n{e}")
            return

        for r in rows:
            self.tree.insert("", "end", values=(
                r.id_tovar, r.article, r.name, r.unit, float(r.price),
                r.discount, r.qty, r.category, r.provider, r.manufacturer
            ))

    def get_selected_id(self):
        sel = self.tree.selection()
        if not sel:
            return None
        values = self.tree.item(sel[0], "values")
        return int(values[0])

    def open_add(self):
        ProductEditor(self, mode="add", product_values=None)

    def open_edit(self):
        pid = self.get_selected_id()
        if pid is None:
            messagebox.showwarning("Внимание", "Выберите товар.")
            return
        sel = self.tree.selection()[0]
        values = self.tree.item(sel, "values")
        ProductEditor(self, mode="edit", product_values=values)

    def delete_selected(self):
        pid = self.get_selected_id()
        if pid is None:
            messagebox.showwarning("Внимание", "Выберите товар.")
            return
        if not messagebox.askyesno("Подтверждение", "Удалить выбранный товар?"):
            return
        try:
            db.delete_product(pid)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось удалить товар.\n\n{e}")
            return
        self.load_products()


# ===========================
# ОКНО ДОБАВЛЕНИЯ/РЕДАКТИРОВАНИЯ ТОВАРА (АДМИН)
# ===========================
class ProductEditor(tk.Toplevel):
    def __init__(self, parent: ProductsWindow, mode: str, product_values):
        super().__init__(parent)
        self.parent = parent
        self.mode = mode
        self.title("Товар — добавление" if mode == "add" else "Товар — редактирование")
        self.geometry("520x620")

        self.resizable(False, False)

        self.categories = db.get_lookup("categories")
        self.providers = db.get_lookup("providers")
        self.manufacturers = db.get_lookup("manufacturers")

        def row(label, y):
            tk.Label(self, text=label).place(x=20, y=y)
        y = 20

        row("Артикул", y); self.e_article = tk.Entry(self, width=45); self.e_article.place(x=150, y=y); y += 35
        row("Название", y); self.e_name = tk.Entry(self, width=45); self.e_name.place(x=150, y=y); y += 35
        row("Ед.", y); self.e_unit = tk.Entry(self, width=45); self.e_unit.place(x=150, y=y); y += 35
        row("Цена", y); self.e_price = tk.Entry(self, width=45); self.e_price.place(x=150, y=y); y += 35
        row("Скидка макс. %", y); self.e_maxdisc = tk.Entry(self, width=45); self.e_maxdisc.place(x=150, y=y); y += 35
        row("Скидка %", y); self.e_disc = tk.Entry(self, width=45); self.e_disc.place(x=150, y=y); y += 35
        row("Количество", y); self.e_qty = tk.Entry(self, width=45); self.e_qty.place(x=150, y=y); y += 35

        row("Категория", y)
        self.cb_cat = ttk.Combobox(self, width=42, state="readonly",
                                   values=[f"{i} — {n}" for i, n in self.categories])
        self.cb_cat.place(x=150, y=y); y += 35

        row("Поставщик", y)
        self.cb_prov = ttk.Combobox(self, width=42, state="readonly",
                                    values=[f"{i} — {n}" for i, n in self.providers])
        self.cb_prov.place(x=150, y=y); y += 35

        row("Производитель", y)
        self.cb_man = ttk.Combobox(self, width=42, state="readonly",
                                   values=[f"{i} — {n}" for i, n in self.manufacturers])
        self.cb_man.place(x=150, y=y); y += 35

        row("Описание", y)
        self.t_desc = tk.Text(self, width=34, height=5)
        self.t_desc.place(x=150, y=y); y += 110

        row("Фото (имя)", y); self.e_photo = tk.Entry(self, width=45); self.e_photo.place(x=150, y=y); y += 50

        tk.Button(self, text="Сохранить", width=18, command=self.save).place(x=150, y=y)
        tk.Button(self, text="Отмена", width=18, command=self.destroy).place(x=320, y=y)

        self.edit_id = None
        if mode == "edit" and product_values:
            self.edit_id = int(product_values[0])
            self.e_article.insert(0, product_values[1])
            self.e_name.insert(0, product_values[2])
            self.e_unit.insert(0, product_values[3])
            self.e_price.insert(0, str(product_values[4]))
            self.e_disc.insert(0, str(product_values[5]))
            self.e_qty.insert(0, str(product_values[6]))
            self.e_maxdisc.insert(0, "0")
            self.cb_cat.current(0)
            self.cb_prov.current(0)
            self.cb_man.current(0)
        else:
            self.cb_cat.current(0)
            self.cb_prov.current(0)
            self.cb_man.current(0)
            self.e_maxdisc.insert(0, "0")
            self.e_disc.insert(0, "0")
            self.e_qty.insert(0, "0")

    def save(self):
        try:
            article = self.e_article.get().strip()
            name = self.e_name.get().strip()
            unit = self.e_unit.get().strip()
            price = float(self.e_price.get().strip())
            max_discount = int(self.e_maxdisc.get().strip())
            discount = int(self.e_disc.get().strip())
            qty = int(self.e_qty.get().strip())
            desc = self.t_desc.get("1.0", "end").strip()
            photo = self.e_photo.get().strip()

            if not article or not name or not unit:
                messagebox.showwarning("Ошибка", "Заполните артикул, название и единицу.")
                return

            id_category = int(self.cb_cat.get().split("—")[0].strip())
            id_provider = int(self.cb_prov.get().split("—")[0].strip())
            id_manufacturer = int(self.cb_man.get().split("—")[0].strip())

            if self.mode == "add":
                db.add_product(article, name, unit, price, max_discount,
                               id_manufacturer, id_provider, id_category,
                               discount, qty, desc, photo)
            else:
                db.update_product(self.edit_id, article, name, unit, price, max_discount,
                                  id_manufacturer, id_provider, id_category,
                                  discount, qty, desc, photo)

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить.\n\n{e}")
            return

        self.parent.load_products()
        self.destroy()

import random
from datetime import date

class CartWindow(tk.Toplevel):
    def __init__(self, parent: ProductsWindow):
        super().__init__(parent)
        self.parent = parent
        self.title("Корзина")
        self.geometry("820x450")

        self.tree = ttk.Treeview(self, columns=("id", "name", "qty"), show="headings", height=12)
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)
        self.tree.heading("id", text="ID товара")
        self.tree.heading("name", text="Название")
        self.tree.heading("qty", text="Кол-во")

        btns = tk.Frame(self)
        btns.pack(fill="x", padx=10)

        tk.Button(btns, text="Увеличить +1", command=self.plus).pack(side="left")
        tk.Button(btns, text="Уменьшить -1", command=self.minus).pack(side="left", padx=6)
        tk.Button(btns, text="Удалить", command=self.remove).pack(side="left", padx=6)
        tk.Button(btns, text="Оформить заказ", command=self.checkout).pack(side="right")

        self.load()


    def load(self):
        for i in self.tree.get_children():
            self.tree.delete(i)

        if not self.parent.cart:
            return

        # подтянем названия товаров из БД через общий список
        rows = db.get_products_filtered("", "AZ")
        name_by_id = {r.id_tovar: r.name for r in rows}

        for pid, qty in self.parent.cart.items():
            self.tree.insert("", "end", values=(pid, name_by_id.get(pid, "???"), qty))

    def selected_pid(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return int(self.tree.item(sel[0], "values")[0])

    def plus(self):
        pid = self.selected_pid()
        if pid is None: return
        self.parent.cart[pid] += 1
        self.load()

    def minus(self):
        pid = self.selected_pid()
        if pid is None: return
        self.parent.cart[pid] -= 1
        if self.parent.cart[pid] <= 0:
            del self.parent.cart[pid]
        self.load()

    def remove(self):
        pid = self.selected_pid()
        if pid is None: return
        del self.parent.cart[pid]
        self.load()

    def checkout(self):
        if not self.parent.cart:
            messagebox.showwarning("Корзина", "Корзина пустая.")
            return

        CheckoutWindow(self.parent, on_done=self.on_order_done)

    def on_order_done(self):
        self.parent.cart = {}
        self.destroy()
        messagebox.showinfo("Заказ", "Заказ успешно оформлен!")

class CheckoutWindow(tk.Toplevel):
    def __init__(self, parent: ProductsWindow, on_done):
        super().__init__(parent)
        self.parent = parent
        self.on_done = on_done
        self.title("Оформление заказа")
        self.geometry("520x220")

        tk.Label(self, text="Пункт выдачи (адрес):").pack(anchor="w", padx=10, pady=(10,0))
        self.addresses = db.get_addresses()
        self.addr_var = tk.StringVar()
        self.cb_addr = ttk.Combobox(self, state="readonly",
                                    values=[f"{i} — {n}" for i,n in self.addresses],
                                    width=60)
        self.cb_addr.pack(padx=10, pady=5)
        if self.addresses:
            self.cb_addr.current(0)

        tk.Label(self, text="Дата окончания (необязательно, формат YYYY-MM-DD):").pack(anchor="w", padx=10, pady=(10,0))
        self.end_entry = tk.Entry(self, width=30)
        self.end_entry.pack(padx=10, pady=5)

        tk.Button(self, text="Подтвердить заказ", command=self.make_order).pack(pady=15)

    def make_order(self):
        try:
            if not self.addresses:
                messagebox.showerror("Ошибка", "Нет адресов в таблице addresses.")
                return

            id_address = int(self.cb_addr.get().split("—")[0].strip())
            id_user = None if self.parent.user is None else self.parent.user["id_user"]

            # код заказа (примерно как в твоей таблице)
            code = random.randint(100, 999999)

            date_end = self.end_entry.get().strip() or None
            id_order = db.create_order(
                id_user=id_user,
                id_address=id_address,
                code=code,
                id_state=1,
                date_start=str(date.today()),
                date_end=date_end
            )

            # позиции
            for pid, qty in self.parent.cart.items():
                db.add_order_item(id_order, pid, qty)

            self.destroy()
            self.on_done()

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось оформить заказ.\n\n{e}")

class OrdersWindow(tk.Toplevel):
    def __init__(self, parent, id_user: int):
        super().__init__(parent)
        self.title("Мои заказы")
        self.geometry("900x450")
        self.id_user = id_user

        self.tree = ttk.Treeview(self, columns=("id","code","start","end","status","address"), show="headings", height=10)
        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

        for c, t in [
            ("id","ID"), ("code","Код"), ("start","Начало"), ("end","Окончание"),
            ("status","Статус"), ("address","Адрес")
        ]:
            self.tree.heading(c, text=t)
            self.tree.column(c, width=120 if c != "address" else 320)

        btns = tk.Frame(self)
        btns.pack(fill="x", padx=10)
        tk.Button(btns, text="Показать состав", command=self.show_items).pack(side="left")

        self.load()

    def load(self):
        for i in self.tree.get_children():
            self.tree.delete(i)

        rows = db.get_orders_for_user(self.id_user)
        for r in rows:
            self.tree.insert("", "end", values=(r.id_order, r.code, r.date_start, r.date_end, r.status, r.address))

    def selected_order_id(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return int(self.tree.item(sel[0], "values")[0])

    def show_items(self):
        oid = self.selected_order_id()
        if oid is None:
            messagebox.showwarning("Внимание", "Выберите заказ.")
            return
        items = db.get_order_items(oid)
        text = "\n".join([f"{it.article} | {it.name} | {it.qty} шт. | {float(it.price)}" for it in items]) or "Нет позиций"
        messagebox.showinfo("Состав заказа", text)
class OrderEditor(tk.Toplevel):
    def __init__(self, parent: OrdersWindow, order_id: int, on_saved):
        super().__init__(parent)
        self.parent = parent
        self.order_id = order_id
        self.on_saved = on_saved

        self.title(f"Редактирование заказа #{order_id}")
        self.geometry("620x260")
        self.resizable(False, False)

        # справочники
        self.states = db.get_states()         # [(id, name)]
        self.addresses = db.get_addresses()   # [(id, name)]

        # ---- Статус ----
        tk.Label(self, text="Статус:").place(x=20, y=25)
        self.state_cb = ttk.Combobox(
            self,
            state="readonly",
            values=[f"{i} — {n}" for i, n in self.states],
            width=55
        )
        self.state_cb.place(x=120, y=25)

        # ---- Адрес ----
        tk.Label(self, text="Пункт выдачи:").place(x=20, y=75)
        self.addr_cb = ttk.Combobox(
            self,
            state="readonly",
            values=[f"{i} — {n}" for i, n in self.addresses],
            width=55
        )
        self.addr_cb.place(x=120, y=75)

        # ---- Дата окончания ----
        tk.Label(self, text="Дата окончания (YYYY-MM-DD):").place(x=20, y=125)
        self.end_entry = tk.Entry(self, width=30)
        self.end_entry.place(x=250, y=125)

        tk.Button(self, text="Сохранить", width=18, command=self.save).place(x=250, y=180)
        tk.Button(self, text="Отмена", width=18, command=self.destroy).place(x=400, y=180)

        # проставим значения по умолчанию из выбранной строки таблицы
        self.prefill_from_selected()

    def prefill_from_selected(self):
        sel = self.parent.tree.selection()
        if not sel:
            self.state_cb.current(0)
            self.addr_cb.current(0)
            return

        values = self.parent.tree.item(sel[0], "values")
        # columns в OrdersWindow: id, code, start, end, status, address, client
        current_status = values[4]
        current_address = values[5]
        current_end = values[3] if values[3] is not None else ""

        # выставляем комбобоксы по названию
        def find_index_by_name(items, name):
            for idx, (_, n) in enumerate(items):
                if str(n) == str(name):
                    return idx
            return 0

        self.state_cb.current(find_index_by_name(self.states, current_status))
        self.addr_cb.current(find_index_by_name(self.addresses, current_address))
        self.end_entry.delete(0, tk.END)
        self.end_entry.insert(0, "" if current_end in (None, "None") else str(current_end))

    def save(self):
        try:
            # 1) Валидация выбора
            if not self.state_cb.get().strip():
                messagebox.showwarning("Ошибка", "Выберите статус.")
                return
            if not self.addr_cb.get().strip():
                messagebox.showwarning("Ошибка", "Выберите пункт выдачи.")
                return

            id_state = int(self.state_cb.get().split("—")[0].strip())
            id_address = int(self.addr_cb.get().split("—")[0].strip())

            date_end = self.end_entry.get().strip()
            if date_end == "":
                date_end = None  # можно оставить пустым

            # 2) Обновление в БД
            db.update_order(self.order_id, id_state, id_address, date_end)

            messagebox.showinfo("Успешно", "Заказ обновлён.")
            self.on_saved()
            self.destroy()

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить заказ.\n\n{e}")

if __name__ == "__main__":
    LoginWindow().mainloop()
